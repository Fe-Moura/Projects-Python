tempo = int(input("Digit o tempo doo percurso: "))
distancia = int(input("Digite a distância percorrida: "))
velocidade_media = (distancia/tempo)

print("A sua velocidade média foi de: {:.1f}".format(velocidade_media))