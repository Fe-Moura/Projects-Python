numero = bin(int(input("Insira um número: ")))
print("A conversão para binário é: {}".format(numero))