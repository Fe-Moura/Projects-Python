#################EXERCÍCIO 3######################
from tkinter import *
from tkinter import messagebox
from math import *

janela = Tk()

janela.title("Calculadora")
janela.geometry("400x400")


def letras():
    valor = (form.get())
    if valor == "a" or valor == "e" or valor == "i" or valor == "o" or valor == "u":
        return letra()
    if valor == "y":
        return y()
    else:
        return consoante()    

def letra():
    form.delete(0,END)
    valor = "vogal"
    form.delete(0,END)
    form.insert(0, valor)
    

def y():     
    form.delete(0,END)
    valor = "vogal(dependendo da língua)"
    form.delete(0,END)
    form.insert(0, valor)

def consoante():      
    form.delete(0,END) 
    valor = "consoante"
    form.delete(0,END)
    form.insert(0, valor)

botao = Button(janela, text="7", command=letras)
botao.place(x=210, y=180, anchor=CENTER)

botao = Button(janela, text="8", command=letras)
botao.place(x=230, y=180, anchor=CENTER)

botao = Button(janela, text="9", command=letras)
botao.place(x=250, y=180, anchor=CENTER)

botao = Button(janela, text="4", command=letras)
botao.place(x=210, y=210, anchor=CENTER)

botao = Button(janela, text="5", command=letras)
botao.place(x=230, y=210, anchor=CENTER)

botao = Button(janela, text="6", command=letras)
botao.place(x=250, y=210, anchor=CENTER)

botao = Button(janela, text="1", command=letras)
botao.place(x=210, y=240, anchor=CENTER)

botao = Button(janela, text="2", command=letras)
botao.place(x=230, y=240, anchor=CENTER)

botao = Button(janela, text="3", command=letras)
botao.place(x=250, y=240, anchor=CENTER)

botao = Button(janela, text="=", command=letras)
botao.place(x=210, y=270, anchor=CENTER)

botao = Button(janela, text="0", command=letras)
botao.place(x=230, y=270, anchor=CENTER)

botao = Button(janela, text="+", command=letras)
botao.place(x=270, y=180, anchor=CENTER)

botao = Button(janela, text="-", command=letras)
botao.place(x=270, y=210, anchor=CENTER)

botao = Button(janela, text="x", command=letras)
botao.place(x=270, y=240, anchor=CENTER)

botao = Button(janela, text="/", command=letras)
botao.place(x=270, y=270, anchor=CENTER)

botao = Button(janela,width=8, text="C", command=letras)
botao.place(x=320, y=180, anchor=CENTER)

botao = Button(janela, text="Sen", command=letras)
botao.place(x=300, y=210, anchor=CENTER)

botao = Button(janela, text="Tan", command=letras)
botao.place(x=300, y=240, anchor=CENTER)

botao = Button(janela, text="Cos", command=letras)
botao.place(x=340, y=210, anchor=CENTER)

botao = Button(janela, text="Log", command=letras)
botao.place(x=340, y=240, anchor=CENTER)

botao = Button(janela,width=2, text="^", command=letras)
botao.place(x=300, y=270, anchor=CENTER)

botao = Button(janela, width=2, text="√", command=letras)
botao.place(x=335, y=270, anchor=CENTER)

form =  Entry(janela, width=15, font=("Arial Bold", 14))
form.place(x=200, y=120)


texto1 = Label(janela, text="Calculadora Ciêntífica", font=("Arial Bold",12))
texto1.place(x=200, y=80)


janela.mainloop()