p1 = int(input("Insira sua nota da P1: "))
p2 = int(input("Insira sua nota da P2: "))
lab = int(input("Insira sua nota do lab: "))
media = ((lab+ 2*p1 + 3*p2)/6)

print("Sua média final é: {0}".format(media))
