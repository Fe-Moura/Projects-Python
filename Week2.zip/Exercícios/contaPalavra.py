from tkinter import * 
from tkinter import scrolledtext

#criando a janela
window= Tk()
window.title("Pesquisa Palavras")
window.geometry("900x600")

#criando a barra de rolagem da pagina
txt = scrolledtext.ScrolledText(window, widt=100, height=25)
txt.place(relx=0.5, rely=0.55, anchor=CENTER)

#Cria as Labels
palavra=Label(window, text="Palavra: ", font=("Arial", 14))
palavra.place(relx=0.05, rely=0.08)

quantidade= Label(window, text="Vezes que aparece: ", font=("Arial", 14))
quantidade.place(relx=0.05, rely=0.13)

#cria as entradas
palavra_entrada= Entry(window, width=15, font=("Arial", 14))
palavra_entrada.place(relx=0.11, rely=0.08)

frequencia= Entry(window, width=15, font=("Arial",14))
frequencia.place(relx=0.25, rely=0.15, anchor=CENTER)

#variavel das vezes que a palavra aparece
qtd=0

#Função que buscaPalavras
def bucar_palavras():
  #abrindo o arquivo
  arquivo = open("chat.txt", "r")
  #lendo o arquivo
  arquivo_read= arquivo.readlines()
  
  for i in range(len(arquivo_read)):
    
    #procurando a palavra
    if arquivo_read[i].find(palavra_entrada.get())!= -1:
      qtd=+1
      txt.insert(10.0,arquivo_read[i])

  frequencia.insert(0,qtd)    


#Criando o botão da busca das palavras
buscar= Button(window, text="Pesquisar palavra", command= bucar_palavras)
buscar.place(relx=0.50, rely=0.08)

window.mainloop()