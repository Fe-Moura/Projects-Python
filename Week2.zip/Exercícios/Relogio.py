from tkinter import *
from datetime import datetime

janela = Tk()
janela.geometry("400x300")
janela.title("Relógio Digital")

data = Label(janela, text="data", font=("Arial Bold", 40), fg="blue")
data.place(relx=0.5, rely=0.35, anchor=CENTER)

hora = Label(janela, text="hora", font=("Arial Bold", 40), fg="blue")
hora.place(relx=0.5, rely=0.6, anchor=CENTER)

def atualiza():
    agora = datetime.now()
    data["text"] = agora.strftime("%d/%m/%Y")
    hora["text"] = agora.strftime("%H:%M:%S")
    janela.after(1000, atualiza)

atualiza()
janela.mainloop()