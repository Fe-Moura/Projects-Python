#################EXERCÍCIO 1######################
from tkinter import *
from tkinter import messagebox

janela = Tk()

janela.title("Conversão Numérica")
janela.geometry("400x400")

texto1 = Label(janela, text="Número decimal:", font=("Arial Bold",14))
texto1.place(relx=0.2, rely=0.2)

form1 =  Entry(janela, width=20, font=("Arial Bold", 14))
form1.place(relx=0.5, rely=0.2)

def binario():
    valor = int(form1.get())
    resultado = bin(valor)
    form2.delete(0,END)
    form2.insert(0, resultado)
    

botao = Button(janela, text="Binário", command=binario)
botao.place(relx=0.3, rely=0.4, anchor=CENTER)

def hexa():
    valor = int(form1.get())
    resultado = hex(valor)
    form2.delete(0,END)
    form2.insert(0, resultado)


botao = Button(janela, text="Hexadecimal", command=hexa)
botao.place(relx=0.5, rely=0.4, anchor=CENTER)

def octal():
    valor = int(form1.get())
    resultado = oct(valor)
    form2.delete(0,END)
    form2.insert(0, resultado)


botao = Button(janela, text="Octal", command=octal)
botao.place(relx=0.7, rely=0.4, anchor=CENTER)

texto2 = Label(janela, text="Resposta:", font=("Arial Bold", 14))
texto2.place(relx=0.3, rely=0.6)

form2 =  Entry(janela, width=10, font=("Arial Bold", 14))
form2.place(relx=0.5, rely=0.6)

janela.mainloop()