#################EXERCÍCIO######################
#Interface gráfica para somar dois números:
from tkinter import *
from tkinter import messagebox

janela = Tk()

janela.title("Soma")
janela.geometry("400x400")

rot1 = Label(janela, text="Entre com o primeiro número:", font=("Arial Bold",14))
rot1.place(relx=0.2, rely=0.2)

rot2 = Label(janela, text="Entre com o segundo número:", font=("Arial Bold", 14))
rot2.place(relx=0.2, rely=0.3)

rot2 = Label(janela, text="Resposta:", font=("Arial Bold", 14))
rot2.place(relx=0.4, rely=0.4)

ent1 =  Entry(janela, width=10, font=("Arial Bold", 14))
ent1.place(relx=0.7, rely=0.2)

ent2 =  Entry(janela, width=10, font=("Arial Bold", 14))
ent2.place(relx=0.7, rely=0.3)

ent3 =  Entry(janela, width=10, font=("Arial Bold", 14))
ent3.place(relx=0.7, rely=0.4)

def soma():
    valor1 = int(ent1.get())
    valor2 = int(ent2.get())
    resultado = valor1+valor2
    ent3.insert(0, resultado)


bot = Button(janela, text="Somar", command=soma)
bot.place(relx=0.5, rely=0.55, anchor=CENTER)

janela.mainloop()

