from tkinter import *
janela = Tk()
janela.title("Exemplo do after") 
janela.geometry("50x50")

label = Label(janela, text="0", font=("Arial Bold", 40))
label.place(relx=0.5, rely=0.5, anchor=CENTER)

contador = 0

def atualiza():
    global contador
    label['text'] = contador
    contador += 1
    janela.geometry(str(50+contador)+"x"+str(50+contador))
    janela.after(100, atualiza)

atualiza()
janela.mainloop()