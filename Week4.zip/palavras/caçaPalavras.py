from tkinter import *
from tkinter import scrolledtext

janela = Tk()
janela.title("Exercício 4")
janela.geometry("1200x900")


numero = Label(janela, text="Tamanho das 3 maiores frases: ", font=("Arial", 20))
numero.place(relx=0.06, rely=0.17)


fraseEntrada = Entry(janela, border=5, width=17, font=("Arial", 15))
fraseEntrada.place(relx=0.27, rely=0.10)


nome = Label(janela, text="Quantidade de Frases: ", font=("Arial", 20))
nome.place(relx=0.06, rely=0.09)

txt = scrolledtext.ScrolledText(janela, width=100, height=23)
txt.place(relx=0.23, rely=0.45)

numero = Label(janela, text="COMPUTACAO.TXT: ", font=("Arial", 40))
numero.place(x=450, y=320)

aparecer = Entry(janela, border=5, width=15, font=("Arial", 20))
aparecer.place(x=480, y=160)

def exercicio4():
    txt.delete(0.1, END)
    aparecer.delete(0,END)
    nome = fraseEntrada.get()
    i = 0
    arquivo = open("palavras/computacao.txt", "r", encoding="utf8")
    for line in arquivo:
        line.strip().split('\n')
        if nome in line:
            i += 1
            txt.insert(INSERT, line+'\n')
    aparecer.insert(0, i)
    arquivo.close()


pesquisar = Button(janela, text="Pesquisar", border=20, font=("Arial", 15), height="5",width="15", command=exercicio4)
pesquisar.place(relx=0.7, rely=0.10)


janela.mainloop()