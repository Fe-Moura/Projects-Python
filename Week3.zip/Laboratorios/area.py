comprimento = float(input("Insira o comprimento desejado: "))
largura = float(input("Insira a largura desejado: "))
area = (largura*comprimento)

print("O valor total da sua área é de: {:.2f}".format(area))