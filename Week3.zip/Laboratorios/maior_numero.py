numeros = int(input("Digite a quantidade de números que serão inseridos:"))
n = 1
maior = 0
while (n!=numeros+1):
    numero = int(input("Insira o número desejado: "))
    print("{0}º número: {1}".format(n,numero))
    n+=1
    if numero > maior:
        maior = numero
print("O maior número inserido é: {}".format(maior))