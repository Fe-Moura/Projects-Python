salario = int(input("Insira o seu salário: "))
aumento = (salario+(salario*0.25))

print("O seu novo salário será de: {:.1f}".format(aumento))