from math import *
Question = input("Vc deseja calcular o volume do Dodecaedro ou do Icosaedro? ")
aresta = int(input(("Informe o tamanho da aresta: ")))
raiz = sqrt(5)
dodecaedro = (((15+7*raiz)/4)*(aresta**3))
icosaedro = ((5/12)*(3+raiz)*(aresta**3))

if Question == "dodecaedro":
    print(dodecaedro)
elif Question == "icosaedro":
    print(icosaedro)