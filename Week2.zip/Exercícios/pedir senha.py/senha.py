def tamanho(password):
    if len(password) >= 8:
        return True
    else:
        return False

def maiuscula(password):
    for caractere in password:
        if caractere.isupper():
            return True
    return False

def minuscula(password):
    for caractere in password:
        if caractere.islower():
            return True
    return False

def numero(password):
    for caractere in password:
        if caractere.isdigit():
            return True
    return False



