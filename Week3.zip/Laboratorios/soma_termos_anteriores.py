n = int(input("Insira o número desejado: "))
soma = ((n*(n+1))/2)
print ("A soma dos primeiros {0} números é {1}".format(n,soma))