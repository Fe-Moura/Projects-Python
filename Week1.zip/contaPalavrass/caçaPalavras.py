from tkinter import *
from tkinter import scrolledtext

#Iniciando a janela
window = Tk()
window.title("ContaPalavras")
window.geometry("900x600")

#criando as labels
palavra = Label(window, text="Palavra Suspeita: ", font=("Arial", 14))
palavra.place(relx=0.05, rely=0.08)

quantidade = Label(window, text="Frequência: ", font=("Arial", 14))
quantidade.place(relx=0.05, rely=0.15)

#criando as inputs (entry)
palavraEntrada = Entry(window, width=15, font=("Arial", 14))
palavraEntrada.place(relx=0.25, rely=0.08)

frequencia = Entry(window, width=15, font=("Arial", 14))
frequencia.place(relx=0.25, rely=0.15)

#cria o scrolledtext
txt = scrolledtext.ScrolledText(window, width=100, height=23)
txt.place(relx=0.05, rely=0.35)

#Função para caçar as palavras e contá-las
def buscaPalavras():
    txt.delete(0.1, END)
    frequencia.delete(0,END)
    palavra = palavraEntrada.get()
    i = 0
    arquivo = open("contaPalavrass/chat.txt", "r")
    for line in arquivo:
        line.strip().split('\n')
        if palavra in line:
            i += 1
            txt.insert(INSERT, line+'\n')
    frequencia.insert(0, i)
    arquivo.close()

#botão
pesquisar = Button(window, text="Pesquisar", command=buscaPalavras)
pesquisar.place(relx=0.5, rely=0.08)

#Label
quantidade = Label(window, text="Ocorrências: ", font=("Arial", 14))
quantidade.place(relx=0.05, rely=0.3)

#chama a função infinitamente
window.mainloop()