#################EXERCÍCIO 2######################
from tkinter import *
from tkinter import messagebox

janela = Tk()

janela.title("Letras")
janela.geometry("400x400")

texto1 = Label(janela, text="Digite aqui a letra:", font=("Arial Bold",14))
texto1.place(relx=0.2, rely=0.2)

form1 =  Entry(janela, width=20, font=("Arial Bold", 14))
form1.place(relx=0.5, rely=0.2)


def letras():
    valor = (form1.get())
    if valor == "a" or valor == "e" or valor == "i" or valor == "o" or valor == "u":
        return letra()
    if valor == "y":
        return y()
    else:
        return consoante()    

def letra():
    form1.delete(0,END)
    valor = "vogal"
    form2.delete(0,END)
    form2.insert(0, valor)
    

def y():     
    form1.delete(0,END)
    valor = "vogal(dependendo da língua)"
    form2.delete(0,END)
    form2.insert(0, valor)

def consoante():      
    form1.delete(0,END) 
    valor = "consoante"
    form2.delete(0,END)
    form2.insert(0, valor)

botao = Button(janela, text="Oque é?", command=letras)
botao.place(relx=0.5, rely=0.4, anchor=CENTER)

texto2 = Label(janela, text="Resposta:", font=("Arial Bold", 14))
texto2.place(relx=0.3, rely=0.6)

form2 =  Entry(janela, width=20, font=("Arial Bold", 14))
form2.place(relx=0.5, rely=0.6)

janela.mainloop()