from math import sqrt
a = float(input("Digite o valor de A: "))
if a == 0:
    print("A equação não é do segundo grau")
else:
    b = float(input("Digite o valor de B: "))
    c = float(input("Digite o valor de C: "))
    delta = b**2 - 4*a*c
    if delta<0:
        print("a equação não possui raízes reais")
    elif delta == 0:
         x = -b / (2*a)
         print ("A equação possui apenas uma raíz: {}".format(x)) 
    else:     
        x1 = (-b + sqrt(delta)) / (2*a)
        x2 = (-b - sqrt(delta)) / (2*a)
        print ("A equação possui 2 raízes: X1 = {0} e X2 {1}".format(x1,x2))