idade = int(input("Digite a idade do usuário: "))

if idade<=2:
    print("O usuário é um bebê")

elif idade>2 and idade<=10:
    print("O usuário é uma Criança")

elif idade>=11 and idade<=17:
    print("O usuário é um(a) Adolescente")

elif idade>=18 and idade<=64:
    print("O usuário é um(a) Adulto(a)")

else:
    print("O usuário é um(a) idoso(a)")