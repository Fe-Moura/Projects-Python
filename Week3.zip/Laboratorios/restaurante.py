refeicao = (float(input("Digite o custo da refeição: ")))
imposto = (refeicao*0.18)
gorjeta = (refeicao*0.10)
total = (refeicao+imposto+gorjeta)
print("")
print ("""O custo da sua refeição: {0} \n 
O valor do imposto: {1} \n
O valor da gorjeta: {2} \n
O valor total da sua conta: {3}""".format(refeicao,imposto,gorjeta,total))
