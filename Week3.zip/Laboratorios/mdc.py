n=int(input("Digite n: "))
m=int(input("Digite m: "))
if m>n:
    d=n
else:
    d=m
while m%d!=0 or n%d!=0:
    d-=1
print(d)